## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment  = "#>",
  fig.width  = 7,
  fig.height = 4
)

## ----setup--------------------------------------------------------------------
library(replayr)

## -----------------------------------------------------------------------------
fp <- system.file("extdata", "sample.fm2", package = "replayr")
mv <- read_movie(fp)
mv

## -----------------------------------------------------------------------------
str(mv, max.level = 1L, give.attr = FALSE)

## -----------------------------------------------------------------------------
c(n_frames(mv), n_players(mv), n_buttons(mv))

## -----------------------------------------------------------------------------
p1 <- player(mv, 1L)
dim(p1)
head(p1)

## -----------------------------------------------------------------------------
press_counts(mv, 1L)

## ----press-rate---------------------------------------------------------------
counts <- press_counts(mv, 1L)
rates  <- counts / n_frames(mv)
barplot(rates,
        las = 2,
        ylab = "fraction of frames held",
        main = "Player 1 press rate by button")

## -----------------------------------------------------------------------------
data.frame(slot = seq_along(universal_buttons()),
           mnemonic = universal_buttons(),
           label = universal_button_names())

## -----------------------------------------------------------------------------
supported_formats()

## -----------------------------------------------------------------------------
bundled <- list.files(system.file("extdata", package = "replayr"),
                      pattern = "^sample\\.", full.names = TRUE)
basename(bundled)

## -----------------------------------------------------------------------------
mv_bk2 <- read_movie(system.file("extdata", "sample.bk2", package = "replayr"))
mv_bk2
press_counts(mv_bk2, 1L)


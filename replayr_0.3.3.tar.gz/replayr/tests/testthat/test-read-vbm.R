test_that("read_vbm() parses the bundled synthetic Game Boy movie", {
  mv <- read_vbm(fixture_path("sample.vbm"))
  expect_s3_class(mv, "replayr_movie")
  expect_equal(mv$header[["_format"]], "vbm")
  expect_equal(n_frames(mv), 3600L)
  expect_equal(n_buttons(mv), 8L)
  expect_equal(mv$header$isGBA, "0")
})

.mk_vbm <- function(words, controller_flags = 1L, system_flags = 0L) {
  hdr <- raw(0x100L)
  hdr[1:4] <- charToRaw("VBM\x1a")
  hdr[5:8] <- writeBin(1L, raw(), size = 4L, endian = "little")
  hdr[13:16] <- writeBin(1L, raw(), size = 4L, endian = "little")
  hdr[22] <- as.raw(controller_flags)
  hdr[23] <- as.raw(system_flags)
  hdr[61:64] <- writeBin(0x100L, raw(), size = 4L, endian = "little")
  body <- unlist(lapply(words, function(w) c(bitwAnd(w, 0xffL), bitwShiftR(w, 8L))))
  tf <- tempfile(fileext = ".vbm")
  writeBin(c(hdr, as.raw(body)), tf)
  tf
}

test_that("read_vbm() decodes grouped SGB controllers", {
  tf <- .mk_vbm(c(1L, 2L), controller_flags = 3L, system_flags = 4L)
  on.exit(unlink(tf))
  mv <- read_vbm(tf)
  expect_equal(dim(mv$inputs), c(1L, 2L, 8L))
  expect_true(mv$inputs[1L, 1L, 8L])
  expect_true(mv$inputs[1L, 2L, 7L])
  expect_equal(mv$header$isSGB, "1")
})

test_that("read_vbm() reads GBA shoulder buttons from system flags", {
  tf <- .mk_vbm(bitwShiftL(1L, 9L), system_flags = 1L)
  on.exit(unlink(tf))
  mv <- read_vbm(tf)
  expect_equal(n_buttons(mv), 12L)
  expect_true(mv$inputs[1L, 1L, 11L])
  expect_equal(mv$header$isGBA, "1")
})

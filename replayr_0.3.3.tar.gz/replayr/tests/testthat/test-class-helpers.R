test_that("player(), press_counts(), n_*() respect array shape", {
  skip_if_no_fixture("sample.fm2")
  mv <- read_fm2(fixture_path("sample.fm2"))
  p1 <- player(mv, 1L)
  expect_true(is.matrix(p1))
  expect_type(p1, "logical")
  expect_equal(nrow(p1), n_frames(mv))
  expect_equal(ncol(p1), n_buttons(mv))
  expect_equal(colnames(p1), mv$button_mnemonics)

  pc <- press_counts(mv, 1L)
  expect_length(pc, n_buttons(mv))
  expect_equal(names(pc), mv$button_names)
  expect_true(all(pc >= 0L))
  expect_true(all(pc <= n_frames(mv)))
})

test_that("print.replayr_movie produces a single header line", {
  skip_if_no_fixture("sample.fm2")
  mv <- read_fm2(fixture_path("sample.fm2"))
  out <- capture.output(print(mv))
  expect_true(any(grepl("replayr_movie", out)))
})
